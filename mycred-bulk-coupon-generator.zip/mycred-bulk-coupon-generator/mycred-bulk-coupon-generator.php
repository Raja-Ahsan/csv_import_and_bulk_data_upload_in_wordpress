<?php
/**
 * Plugin Name: myCred bulk Coupon generator
 * Plugin URI: https://mycred.me
 * Description: This addon will allow admin to create and print coupons in bulk. Just assign the point type, coupon amount, and the number of coupons supposed to print, also choose a custom coupon image to be printed.
 * Version: 1.0
 * Author: myCred
 * Author URI: https://mycred.me
 * License: GPLv2 or later
 */

class mycred_bulk_coupon_generator{
	
	// Plugin Version
	public $version = '1.0';

	/**
	* Construct
	**/
	function __construct()
    {
		$this->bcg_define_constants();
		$this->bcg_init();
	}
	
	/**
	* Give define constants
	**/ 
	 private function bcg_define_constants() {
		$this->define( 'myCred_BCG_Addon_VERSION',$this->version);
		$this->define( 'MYCRED_BCG_SLUG','myCred-bcg');
		$this->define( 'MYCRED_BCG',__FILE__ );
		$this->define( 'MYCRED_BCG_ROOT_DIR',       plugin_dir_path(MYCRED_BCG) );
		$this->define( 'MYCRED_BCG_ASSETS_DIR_URL', plugin_dir_url(MYCRED_BCG) . 'assets/' );
		$this->define( 'MYCRED_BCG_INCLUDES_DIR',   MYCRED_BCG_ROOT_DIR . 'includes/' );
		$this->define( 'MYCRED_BCG_INCLUDES_DIR_IMG',   MYCRED_BCG_INCLUDES_DIR . 'images/' );
		$this->define( 'MYCRED_BCG_INCLUDES_DIR_JS',   MYCRED_BCG_INCLUDES_DIR . 'js/' );
		
		/* Ajax Value */
		add_action( 'wp_ajax_bcg_save_entry',  array($this, 'bcg_save_entry'));
		add_action( 'wp_ajax_nopriv_bcg_save_entry', array($this, 'bcg_save_entry'));
		add_action( 'wp_ajax_myprefix_get_image', array($this,'myprefix_get_image' ));
	}

	/**
	* Give Initialize
	**/
	private function bcg_init() {
		$this->file( ABSPATH . 'wp-admin/includes/plugin.php' );
		if(is_plugin_active('mycred/mycred.php') && is_plugin_active('mycred-bulk-coupon-generator/mycred-bulk-coupon-generator.php')) {
			add_action('admin_menu', array( $this, 'bcg_setup_menu'));
			add_action( 'admin_enqueue_scripts', array( $this,'load_wp_media_files'));
			add_action('admin_enqueue_scripts', array( $this, 'bcg_frontend_scripts'));
		}
		add_action( 'admin_notices',array( $this, 'bcg_required_plugin_notices' ) ); 
	}

	/**
	* Check Define Path
	**/
	private function define( $name, $value ) {
		if ( ! defined( $name ) )
			define( $name, $value );
	}
	/**
	* Check Required Files
	**/
	public function file( $required_file ) {
		if ( file_exists( $required_file ) )
			require_once $required_file;
	}
	
	/**
	* Setup Sub Menu
	**/
	public function bcg_setup_menu(){
		add_submenu_page( 'mycred', 'Coupons Generator', 'Coupons Generator','manage_options', 'mycred-bulk-coupons-generator', array( $this, 'bcg_include'),4);
	}
		
	/**
	* Include Page
	**/
	public function bcg_include() {
		$this->file(MYCRED_BCG_INCLUDES_DIR.'page/form_fields.php');
	}
	
	/**
	* Load wp media files  
	**/
	public function load_wp_media_files( $page ) {
	  // change to the $page where you want to enqueue the script
	  // Enqueue WordPress media scripts
		wp_enqueue_media();
		// Enqueue custom script that will interact with wp.media
		wp_enqueue_script( 'myCred_bcg_script', plugins_url( 'includes/js/myscript.js' , __FILE__ ), array('jquery'), false,false );
	  
	}
	
	/**
	* Load Frontend Scripts  
	**/
	public function bcg_frontend_scripts(){
		if(isset($_GET['page'])){
			$currenr_page = $_GET['page'];
		}else{
			$currenr_page = "";
		}
		if ($currenr_page == 'mycred-bulk-coupons-generator') {
			//css
			wp_enqueue_style('myCred_bcg_admin_style',plugins_url( 'includes/css/style.css' , __FILE__ ),array(),'1.0');
			// Main javascipt file
			wp_enqueue_script('myCred_bcg_ajaxurl', plugins_url('includes/js/script.js', __FILE__),array('jquery'),false,true);
			// AJAX: request
			wp_localize_script('myCred_bcg_ajaxurl', 'myCred_bcg_frontend_scripts_obj', array('ajax_url' => admin_url('admin-ajax.php')));
		}
	}
	
	/**
	* Save Entry  
	**/
	public function bcg_save_entry(){
		// get post data
		$bcg_points_type = $_POST['bcg_points_type'];
		$bcg_coupons_value = $_POST['bcg_coupons_value'];
		$bcg_no_of_coupons = $_POST['bcg_no_of_coupons'];
		$coupons_per_request = $_POST['coupons_per_request'];
		$bcg_logo = $_POST['bcg_logo']; 
		$bcg_suffix = $_POST['bcg_suffix'];
		$bcg_prefix = $_POST['bcg_prefix'];
		if (!empty($bcg_points_type)) {
			if (!empty($bcg_no_of_coupons)) {
				/* if (!empty($bcg_logo)) { */
					// Create coupon code
					$coupon_code_array = [];
					for($i =0; $i< $coupons_per_request; $i++){
					$coupon_code = $this->random_strings(5); 
					// Create post title
					$post_title = $bcg_prefix.$coupon_code.$bcg_suffix; 
					$coupon_code_array[] =$post_title;
					$user_id = get_current_user_id();
					$my_post = array(
					  'post_title'    => $post_title,
					  'post_name'     => $post_title,
					  'post_status'   => 'publish',
					  'post_type'   => 'mycred_coupon',
					  'post_author'   => $user_id,
					);
					// Insert the post into the database
					$post_id = wp_insert_post( $my_post );
						//Add Post Meta Values
						add_post_meta($post_id, 'user', 1);
						add_post_meta($post_id, 'global', 1);
						add_post_meta($post_id, 'type', $bcg_points_type);
						add_post_meta($post_id, 'value', $bcg_coupons_value);
						add_post_meta($post_id, 'max_balance_type', $bcg_points_type);
						add_post_meta($post_id, 'max_balance', 0);
						add_post_meta($post_id, 'min_balance_type', $bcg_points_type);
						add_post_meta($post_id, 'min_balance', 0);
						add_post_meta($post_id, 'usage-count', 0);
					//return response
					
					}
					wp_send_json_success($coupon_code_array);
				/* }else { wp_send_json_error();} */
			}else { wp_send_json_error();}
		} else { wp_send_json_error();}
	}
	
	/**
	* Create Random strings   
	**/
	public function random_strings($length_of_string){ 
		// String of all alphanumeric character 
		$str_result = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'; 
		// Shufle the $str_result and returns substring 
		// of specified length 
		return substr(str_shuffle($str_result),0, $length_of_string); 
	}	
	
	/**
	* Create myprefix get image 
	**/
	public function myprefix_get_image() {
		if(isset($_GET['id']) ){
			$image = wp_get_attachment_image( filter_input( INPUT_GET, 'id', FILTER_VALIDATE_INT ), 'medium', false, array( 'id' => 'myprefix-preview-image' ) );
			$data = array(
				'image'    => $image,
			);
			wp_send_json_success( $data );
		} else {
			wp_send_json_error();
		}
	}
	
	/**
	* Give wp required plugin notices
	**/
	public function bcg_required_plugin_notices() {

		$msg = __( 'need to be active and installed to use myCred plugin.', 'myCred_GWP' );
		$msg_zoom = __( 'need to be active and installed to use myCred bulk coupons generator plugin.', 'myCred_GWP' );
		if ( !is_plugin_active('mycred/mycred.php') ) {
			printf( '<div class="notice notice-error"><p><a href="https://wordpress.org/plugins/mycred/">%1$s</a> %2$s</p></div>', __( 'myCred', 'myCred_GWP' ), esc_html( $msg ) );
		} 
		if(!class_exists('myCRED_Coupons_Module')){
			printf( '<div class="notice notice-error"><p><a href="https://codex.mycred.me/chapter-iii/coupons/">%1$s</a> %2$s</p></div>', __( 'Coupons Add-on', 'myCred_GWP' ), esc_html( $msg_zoom ) );
			deactivate_plugins('/mycred-bulk-coupon-generator/mycred-bulk-coupon-generator.php');
		}
	}
	//End Class
}
new mycred_bulk_coupon_generator(); 





