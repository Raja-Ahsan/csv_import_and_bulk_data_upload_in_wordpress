<?php

/** 
*	Set points type value
**/
$options = '<option value="">Select Point Type</option>';
$points_type_value="";
$types = mycred_get_types();
if(!empty($types)){
	foreach ( $types as $type => $label ){
		$options .= '<option value="' .$type. '" ' .selected($points_type_value, $type, false). '>'. $label .'</option>';
	}
}

/** 
*	Set Image value
**/
$image_id = get_option( 'myprefix_image_id' );
if( intval( $image_id ) > 0 ) {
	// Change with the image size you want to use
    $image = wp_get_attachment_image( $image_id, 'medium', false, array( 'id' => 'myprefix-preview-image' ) );
} else {
    // Some default image
    $image = '<div id="myprefix-preview-image"></div>';
}

?>

<div class="mycred_bcg_box_head">
	<div class="mycred_bcg_thumbnail">
			<img  class="mycred_bcg_thumbnail_image" src="<?= plugins_url( 'mycred-bulk-coupon-generator/includes/images/badge.png');?>" alt="">
	</div>
	<div class="mycred_bcg_review_text">
		<h3>myCred Bulk Coupons Generator</h3>
	</div>
</div>
<div class="row">
	<div class="column">
    	<label>1. SELECT POINT TYPE</label>
		<select name="bcg_points_type" id="bcg_points_type" required="required" class="mycred_bcg_box_field bcg_col_4">
			<?= $options; ?>
		</select>
	</div>
	<div class="column">
		<label>2. ADD COUPONS AMOUNT</label>
    	<input type="number" name="bcg_coupons_value" id="bcg_coupons_value" class="mycred_bcg_box_field bcg_col_4" placeholder="Enter Amount" required="required" />
	</div>
	<div class="column">
    	<label>3. NUMBER OF COUPONS</label>
		<input type="number" name="bcg_no_of_coupons" id="bcg_no_of_coupons" class="mycred_bcg_box_field bcg_col_4" placeholder="Number of coupons" required="required" />
	</div>
	<div class="column">
		<label>4. SELECT COUPONS IMAGE</label>
		
		<input type="hidden" name="myprefix_image_id" id="myprefix_image_id" value="<?php echo esc_attr( $image_id ); ?>" class="regular-text" />
		<input type='button' value="<?php esc_attr_e( 'Select a image', 'mytextdomain' ); ?>" class="myprefix_media_manager mycred_bcg_box_field bcg_col_4 button-primary"/>
		<span><?= $image; ?></span>
		
	</div>
	<div class="mycred_bcg_show_more">MORE OPTIONS</div>
	<div class="mycred_bcg_show_line"></div>
	<div class="mycred_bcg_more_fields" id="another-element">
		<input type="hidden" id="bcg_toggle" value="1">
		<div class="bcg_left">
			<input type="text" name="bcg_suffix" id="bcg_suffix" class="mycred_bcg_box_field bcg_col_2" placeholder="Set Coupons Code Suffix Optional" />
		</div>
		<div class="bcg_right">
			<input type="text" name="bcg_prefix" id="bcg_prefix" class="mycred_bcg_box_field bcg_col_2" placeholder="Set Coupons Code Prefix Optional" />
		</div>
	</div>
	<p class="bcg_save_button">
		<input type="submit" value="Genrate Coupons" class="bcg_save"/>
	</p>
	<div class="progress">
		<div class="bar" style="width:0%"></div>
		<div class="percent" style="width:0%">0%</div>
	</div>
	<p class="bcg_save_button">
		<input type='button' id='btn' value='Print Coupons' onclick='printDiv();' class="bcg_print">
	</p>
</div>


<div class="mycred_bcg_coupon_box">
	<div class="output_code" id="DivIdToPrint"></div>
</div>










