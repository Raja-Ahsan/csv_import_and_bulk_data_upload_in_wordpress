/**
 * Select Post Id - AJAX
 */
var coupons_inserted = 0;
jQuery('body').on('click', '.bcg_save', function() {
	coupons_inserted = 0;
	var response_value = 0;
	var coupons_per_request = 20;
	var bcg_points_type = jQuery('#bcg_points_type').val();
	var bcg_coupons_value = jQuery('#bcg_coupons_value').val();
	var bcg_no_of_coupons = jQuery('#bcg_no_of_coupons').val();
	
	
	if(bcg_points_type ==""){
		alert('Kindly select point type');
	}else{
		if(bcg_coupons_value ==""){
			alert('Kindly add coupon amount');
		}else{
			if(bcg_no_of_coupons ==""){
				alert('Kindly add no of coupons');
			}else{
				//Progress Bar
				jQuery('.progress').css("display", "block");
				jQuery('.mycred_bcg_coupon_box').css("display", "block");
				var percentValue = '0%';
				jQuery('.bar').width(percentValue);
				jQuery('.percent').width(percentValue);
				jQuery('.percent').html(percentValue);
				jQuery('.output_code').html('');
				if( bcg_no_of_coupons < coupons_per_request ) {
					coupons_per_request = bcg_no_of_coupons;
				}
				//call back function
				call_back(bcg_no_of_coupons,response_value,coupons_per_request);
			}
		}
	}
	
	
});


/** 
*Call back Function 
**/
function call_back(bcg_no_of_coupons,response_value,coupons_per_request){
	if(bcg_no_of_coupons == response_value){
		console.log('done');
		jQuery('.bcg_print').css("display", "block");
	}else{
		call_ajax(response_value,coupons_per_request);
	}
}
/**
* Ajax Function 
**/
function call_ajax(response_value,coupons_per_request){
	var counter = 0;
	var bcg_points_type = jQuery('#bcg_points_type').val();
	var bcg_coupons_value = jQuery('#bcg_coupons_value').val();
	var bcg_no_of_coupons = jQuery('#bcg_no_of_coupons').val();
	var image_link = jQuery('#myprefix-preview-image').attr("src");
	var bcg_logo = image_link; 
	var bcg_suffix = jQuery('#bcg_suffix').val();
	var bcg_prefix = jQuery('#bcg_prefix').val(); 
	
	var data = {
		'action': 'bcg_save_entry',
		'bcg_points_type': bcg_points_type,
		'bcg_coupons_value': bcg_coupons_value,
		'bcg_no_of_coupons': bcg_no_of_coupons,
		'bcg_logo': bcg_logo,
		'bcg_suffix': bcg_suffix,
		'bcg_prefix': bcg_prefix,
		'coupons_per_request': coupons_per_request,
	};
	
	jQuery.post(myCred_bcg_frontend_scripts_obj.ajax_url, data, function(response) { 
			if(response.success === true){
				var code;
				jQuery.each(response.data, function(i, code) {
					if(bcg_logo !=="" && bcg_logo !== undefined ){
						jQuery('.output_code').append('<div class="image_div"><span class="coupon_code">'+code+'</span><img src="'+bcg_logo+'" alt="Upload Image" class="coupon_image"></div>'); 
					}else{
						jQuery('.output_code').append('<div class="without_image_div"><span class="coupon_code_without_image">'+code+'</span></div>'); 
					}
					counter++;
				});
				response_value = counter;
				console.log(response_value+"new inserted");
				// Count no of coupons added
				coupons_inserted += response_value;
				
				// Getting remaining coupons count
				var remaining_coupons = bcg_no_of_coupons - coupons_inserted; //4
				
				// If remaing coupons are less than coupon per request, then override coupons per request value
				if( remaining_coupons < coupons_per_request ) {
					coupons_per_request = remaining_coupons;
				}
				//Show print button
				if(remaining_coupons == 0){
					//console.log('done');
					jQuery('.bcg_print').css("display", "block");
				}
				// Jquery Progress Bar
					percentText = Math.round(coupons_inserted * 100 / bcg_no_of_coupons);
					jQuery('.bar').width(percentText+ "%");
					jQuery('.percent').width(percentText+ "%");
					jQuery('.percent').html(percentText + "%");
				// Send coupon request again where
				if( remaining_coupons > 0 ) {
					call_back(bcg_no_of_coupons,response_value,coupons_per_request);
				}
			}
	});
	// wp ajax
}



/**
* Print All Coupon
**/
function printDiv(){
	var divToPrint = document.getElementById('DivIdToPrint');
	var newWin=window.open('','Print-Window');
	newWin.document.open();
	newWin.document.write('<html><body onload="window.print()"><style>.output_code{text-align: center; display: inline-block;padding: 15px;}.image_div { float:left; width: 350px; height:auto; border: dashed 1px black; padding: 20px 0px;text-align: center;display: inherit;margin-top: -1px;margin-left: -1px;} .coupon_code{ position: absolute;margin-top: 14px; margin-left: 50px;font-size: 14px;font-weight: 900;font-family: sans-serif;color: #072a73; border-radius: 0px 10px 0px 10px;background-color: #fcf003; padding: 0px 10px;}.coupon_code_without_image{font-size: 12px;font-weight: bold;color: black;background-color: white;padding: 0px 19px;border: solid 2px;}.without_image_div{float: left;width: 150px;margin-bottom:20px;}</style>'+divToPrint.innerHTML+'</body></html>');
	newWin.document.close();
	setTimeout(function(){newWin.close();},5);
}


/**
* Show Hide 
**/
jQuery('.mycred_bcg_show_more').click(function() {
	
	bcg_toggle_value = jQuery('#bcg_toggle').val();
	if(bcg_toggle_value == 1){
		jQuery('#bcg_toggle').attr('value', ''); 
		jQuery('.mycred_bcg_more_fields').show();
	}else{
		jQuery('#bcg_toggle').val(1);
		jQuery('.mycred_bcg_more_fields').hide();
	}
});


